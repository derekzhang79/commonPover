var leftUnm=0;
	var rightNum = 0;
	var timer = null;
	var isdrag=false;   
	var tx,x; 
		mui.plusReady(function(){
//			mui(".box").on("swipeleft",".mui-table-view",preMovie);
//			mui(".box").on("swiperight",".mui-table-view",nextMovie);
			$("#moveid .mui-table-view-cell").on("tap",function(){
				
				var unm =$(this).index()-1 ;
				var status = this.getAttribute("status");
				console.log(status);
				$(".active").css("left",+12.5*unm+'%');
				$(".active").css("transition","all .5s ease .1s");
//				$(".mui-table-view ").css("margin-left",'-'+25*unm+'%'); 
//			$(".mui-table-view ").css("transition","all 1s ease .1s")
//				tx=0
			})
			
			//打开设置
			$("#openSetting").on("tap",function(){
				var UIApplication = plus.ios.import("UIApplication");
				var NSURL = plus.ios.import("NSURL");
				var setting = NSURL.URLWithString("app-settings:");
				var application = UIApplication.sharedApplication();
				application.openURL(setting);
				plus.ios.deleteObject(setting);
//				plus.ios.deleteObject(application);
			})
			//拖拽
			document.getElementById("moveid").addEventListener('touchend',function(){  
		        sdrag = false;  
		    },false);  
		    document.getElementById("moveid").addEventListener('touchstart',selectmouse,false);  
		    document.getElementById("moveid").addEventListener('touchmove',movemouse,false); 
		    
		    //猜您喜欢
		    TouchSlide({ 
				slideCell:"#picScroll",
				titCell:".hd ul", //开启自动分页 autoPage:true ，此时设置 titCell 为导航元素包裹层
				autoPage:true, //自动分页
				pnLoop:"false", // 前后按钮不循环
				switchLoad:"_src" //切换加载，真实图片路径为"_src" 
			});
			
		})
		function preMovie(){
			leftUnm=leftUnm+1;
			console.log("leftUnm=="+leftUnm)
			var item = $(this);
			var right = parseInt($(".mui-table-view ").css("marginLeft"));
			$(".mui-table-view ").css("margin-left",'-'+25*leftUnm+'%'); 
			$(".mui-table-view ").css("transition","all 1s ease .1s")
			$(".active").css("left",+12.5*leftUnm+'%');
			$(".active").css("transition","all .5s ease .1s");
			
		}
		function nextMovie(){
			var item = $(this);
			var right = parseInt($(".mui-table-view ").css("marginLeft"));
			$(".mui-table-view ").css("margin-left",'-'+25*(leftUnm-1)+'%'); 
			$(".mui-table-view ").css("transition","all 1s ease .1s");
			leftUnm=leftUnm-1;
			if(leftUnm<0){
				leftUnm=0	
			}
			$(".active").css("left",+12.5*leftUnm+'%');
			$(".active").css("transition","all .5s ease .1s");
		}
		
		//拖拽
		function movemouse(e){   
		  if (isdrag){   
		   var n = tx + e.touches[0].pageX - x; 
		   var nowWidth = plus.screen.resolutionWidth;//获取当前屏幕的宽度
		   if(n>1||n<=-nowWidth){
		   	return false;
		   }
		   $("#moveid").css("left",n);  
		   return false;   
		   }   
		}   
		 
		function selectmouse(e){   
		   isdrag = true;   
		   tx = parseInt(document.getElementById("moveid").style.left+0);   
		   x = e.touches[0].pageX;    
		   return false;   
		}